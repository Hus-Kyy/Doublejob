Locales['fr'] = {

	['new_job'] = 'vous avez un nouveau job secondaire!',
	['access_job_center'] = 'appuyez sur ~INPUT_PICKUP~ pour accéder au ~b~emploi secondaire~s~.',
	['job_center'] = 'pôle-Emploi',

}

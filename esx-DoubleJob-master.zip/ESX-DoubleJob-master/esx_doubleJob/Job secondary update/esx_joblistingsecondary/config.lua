Config              = {}
Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 2.0, y = 2.0, z = 0.5}
Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 1
Config.Locale = 'fr'

Config.Zones = {
	{x = -336.220, y = -928.173, z = 30.500}
}




# ESX-DoubleJob fonctionnelle avec double paye

J'ai t�l�charger la versions original du scripts : https://forum.fivem.net/t/release-having-2-jobs/97000/81 . Ou il est dis qu'il y � quelques beugs et j'ai donc passer mon temps � tout remettre dans l'ordre afin que cela fonctionne sans probl�me.

Je vous ai mis dans le dossier Job secondary update des m�tiers pr�ts � l'emploi pour le double Job , concernant les m�tier White List il � un exemple du m�tier esx_policejob avec toutes les modifications � apport�s coter client.

Recquis pour l'installation : 

- esx_joblistingsecondary fourni ( c'est le esx_joblisting que j'ai modifier et j'ai fais de m�me pour le esx_jobs )

Installation :

- Appliquez le SQL dans votre base de donn�es 

- Placer es_extended dans votre dossier ressource ( si vous l'avez d�ja effacer l'ancienne versions avant d'installer celle-ci ).

- Placer esx_society dans votre dossier ressource ( si vous l'avez d�ja effacer l'ancienne versions avant d'installer celle-ci ).

- Placer les m�tiers secondaire dans votre dossier ressources et appliquez leurs SQL si vous ne poss�der pas les originaux.

- Dans votre server.cfg : 

```
start es_extended
start esx_society
start esx_cityworkssecondary
start esx_garbagesecondary
start esx_gardenersecondary
start esx_gopostalsecondary
start esx_joblistingsecondary
start esx_jobssecondary
start esx_marathonjobsecondary
start esx_poolcleanersecondary
start esx_truckerjobsecondary 
```

Les scripts originaux sur Github : 

- es_extended : https://github.com/ESX-Org/es_extended

- esx_policejob : https://github.com/ESX-Org/esx_policejob

- esx_society : https://github.com/ESX-Org/esx_society


By Hus-kyy
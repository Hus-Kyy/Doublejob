server_scripts {
    '@es_extended/locale.lua',
	'locales/de.lua',
	'locales/en.lua',
    'locales/fr.lua',
	'config.lua',
	'server/main.lua'
}

client_scripts {
	'@es_extended/locale.lua',
	'locales/de.lua',
	'locales/en.lua',
    'locales/fr.lua',
	'config.lua',
	'client/main.lua'
}
# esx_gardener

Gardener Job for ESX

# Getting Started

1. Add esx_gardener folder into resources
2. Add in server.cfg
3. Add esx_gardener.sql to database

# Configuration

1. Configuration only in config.lua

Thanks to Anthony for esx_garbage, wich is the base of all of this.
https://github.com/AnthonyEl